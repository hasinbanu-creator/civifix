globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/9f8a9280b3b47840.js",
      "static/chunks/turbopack-d87a44654e634267.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/9f8a9280b3b47840.js",
      "static/chunks/turbopack-6264e8ebf1af55b4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3d1dc86dbe1f5363.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/235d6bf3a14b5b25.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/95430665afb49fa0.js",
    "static/chunks/turbopack-ffd190cf245abbd4.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];